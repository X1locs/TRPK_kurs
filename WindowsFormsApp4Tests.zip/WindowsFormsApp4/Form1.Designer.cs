﻿namespace WindowsFormsApp4
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label d_descriptionLabel;
            System.Windows.Forms.Label d_avtorLabel;
            System.Windows.Forms.Label museumObject_BookIncome_B_idLabel1;
            System.Windows.Forms.Label i_dateLabel;
            System.Windows.Forms.Label museumObject_BookIncome_B_idLabel;
            System.Windows.Forms.Label location_idLocationLabel;
            System.Windows.Forms.Label fund_idFundLabel;
            System.Windows.Forms.Label m_safetyLabel;
            System.Windows.Forms.Label m_materialLabel;
            System.Windows.Forms.Label m_sizeLabel;
            System.Windows.Forms.Label m_nameLabel;
            System.Windows.Forms.Label bookIncome_B_idLabel;
            System.Windows.Forms.Label b_wayLabel;
            System.Windows.Forms.Label b_timeLabel;
            this.dataSet1 = new WindowsFormsApp4.DataSet1();
            this.bookIncomeBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.bookIncomeTableAdapter = new WindowsFormsApp4.DataSet1TableAdapters.BookIncomeTableAdapter();
            this.tableAdapterManager = new WindowsFormsApp4.DataSet1TableAdapters.TableAdapterManager();
            this.descriptionTableAdapter = new WindowsFormsApp4.DataSet1TableAdapters.DescriptionTableAdapter();
            this.inventoryTableAdapter = new WindowsFormsApp4.DataSet1TableAdapters.InventoryTableAdapter();
            this.museumObjectTableAdapter = new WindowsFormsApp4.DataSet1TableAdapters.MuseumObjectTableAdapter();
            this.museumObjectBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.inventoryBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.descriptionBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.button12 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.museumObject_BookIncome_B_idComboBox1 = new System.Windows.Forms.ComboBox();
            this.d_avtorTextBox = new System.Windows.Forms.TextBox();
            this.d_descriptionTextBox = new System.Windows.Forms.TextBox();
            this.descriptionDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn15 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.button11 = new System.Windows.Forms.Button();
            this.fund_idFundComboBox = new System.Windows.Forms.ComboBox();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.location_idLocationTextBox = new System.Windows.Forms.TextBox();
            this.museumObject_BookIncome_B_idComboBox = new System.Windows.Forms.ComboBox();
            this.i_dateDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.inventoryDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.button10 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.bookIncome_B_idComboBox = new System.Windows.Forms.ComboBox();
            this.m_nameTextBox = new System.Windows.Forms.TextBox();
            this.m_sizeTextBox = new System.Windows.Forms.TextBox();
            this.m_materialTextBox = new System.Windows.Forms.TextBox();
            this.m_safetyTextBox = new System.Windows.Forms.TextBox();
            this.museumObjectDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.button9 = new System.Windows.Forms.Button();
            this.bookIncomeDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.b_wayTextBox = new System.Windows.Forms.TextBox();
            this.b_timeDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.button13 = new System.Windows.Forms.Button();
            d_descriptionLabel = new System.Windows.Forms.Label();
            d_avtorLabel = new System.Windows.Forms.Label();
            museumObject_BookIncome_B_idLabel1 = new System.Windows.Forms.Label();
            i_dateLabel = new System.Windows.Forms.Label();
            museumObject_BookIncome_B_idLabel = new System.Windows.Forms.Label();
            location_idLocationLabel = new System.Windows.Forms.Label();
            fund_idFundLabel = new System.Windows.Forms.Label();
            m_safetyLabel = new System.Windows.Forms.Label();
            m_materialLabel = new System.Windows.Forms.Label();
            m_sizeLabel = new System.Windows.Forms.Label();
            m_nameLabel = new System.Windows.Forms.Label();
            bookIncome_B_idLabel = new System.Windows.Forms.Label();
            b_wayLabel = new System.Windows.Forms.Label();
            b_timeLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bookIncomeBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.museumObjectBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.inventoryBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.descriptionBindingSource)).BeginInit();
            this.tabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.descriptionDataGridView)).BeginInit();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.inventoryDataGridView)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.museumObjectDataGridView)).BeginInit();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bookIncomeDataGridView)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.SuspendLayout();
            // 
            // d_descriptionLabel
            // 
            d_descriptionLabel.AutoSize = true;
            d_descriptionLabel.Location = new System.Drawing.Point(914, 80);
            d_descriptionLabel.Name = "d_descriptionLabel";
            d_descriptionLabel.Size = new System.Drawing.Size(75, 16);
            d_descriptionLabel.TabIndex = 5;
            d_descriptionLabel.Text = "Описание:";
            // 
            // d_avtorLabel
            // 
            d_avtorLabel.AutoSize = true;
            d_avtorLabel.Location = new System.Drawing.Point(914, 52);
            d_avtorLabel.Name = "d_avtorLabel";
            d_avtorLabel.Size = new System.Drawing.Size(50, 16);
            d_avtorLabel.TabIndex = 3;
            d_avtorLabel.Text = "Автор:";
            // 
            // museumObject_BookIncome_B_idLabel1
            // 
            museumObject_BookIncome_B_idLabel1.AutoSize = true;
            museumObject_BookIncome_B_idLabel1.Location = new System.Drawing.Point(914, 22);
            museumObject_BookIncome_B_idLabel1.Name = "museumObject_BookIncome_B_idLabel1";
            museumObject_BookIncome_B_idLabel1.Size = new System.Drawing.Size(21, 16);
            museumObject_BookIncome_B_idLabel1.TabIndex = 1;
            museumObject_BookIncome_B_idLabel1.Text = "id:\r\n";
            // 
            // i_dateLabel
            // 
            i_dateLabel.AutoSize = true;
            i_dateLabel.Location = new System.Drawing.Point(799, 106);
            i_dateLabel.Name = "i_dateLabel";
            i_dateLabel.Size = new System.Drawing.Size(130, 16);
            i_dateLabel.TabIndex = 7;
            i_dateLabel.Text = "Дата поступления:";
            // 
            // museumObject_BookIncome_B_idLabel
            // 
            museumObject_BookIncome_B_idLabel.AutoSize = true;
            museumObject_BookIncome_B_idLabel.Location = new System.Drawing.Point(799, 18);
            museumObject_BookIncome_B_idLabel.Name = "museumObject_BookIncome_B_idLabel";
            museumObject_BookIncome_B_idLabel.Size = new System.Drawing.Size(88, 16);
            museumObject_BookIncome_B_idLabel.TabIndex = 5;
            museumObject_BookIncome_B_idLabel.Text = "id предмета:";
            // 
            // location_idLocationLabel
            // 
            location_idLocationLabel.AutoSize = true;
            location_idLocationLabel.Location = new System.Drawing.Point(799, 78);
            location_idLocationLabel.Name = "location_idLocationLabel";
            location_idLocationLabel.Size = new System.Drawing.Size(112, 16);
            location_idLocationLabel.TabIndex = 3;
            location_idLocationLabel.Text = "Местохранения:";
            // 
            // fund_idFundLabel
            // 
            fund_idFundLabel.AutoSize = true;
            fund_idFundLabel.Location = new System.Drawing.Point(799, 48);
            fund_idFundLabel.Name = "fund_idFundLabel";
            fund_idFundLabel.Size = new System.Drawing.Size(45, 16);
            fund_idFundLabel.TabIndex = 14;
            fund_idFundLabel.Text = "Фонд:";
            // 
            // m_safetyLabel
            // 
            m_safetyLabel.AutoSize = true;
            m_safetyLabel.Location = new System.Drawing.Point(908, 132);
            m_safetyLabel.Name = "m_safetyLabel";
            m_safetyLabel.Size = new System.Drawing.Size(94, 16);
            m_safetyLabel.TabIndex = 9;
            m_safetyLabel.Text = "Сохранность:";
            // 
            // m_materialLabel
            // 
            m_materialLabel.AutoSize = true;
            m_materialLabel.Location = new System.Drawing.Point(908, 104);
            m_materialLabel.Name = "m_materialLabel";
            m_materialLabel.Size = new System.Drawing.Size(76, 16);
            m_materialLabel.TabIndex = 7;
            m_materialLabel.Text = "Материал:";
            // 
            // m_sizeLabel
            // 
            m_sizeLabel.AutoSize = true;
            m_sizeLabel.Location = new System.Drawing.Point(908, 76);
            m_sizeLabel.Name = "m_sizeLabel";
            m_sizeLabel.Size = new System.Drawing.Size(97, 16);
            m_sizeLabel.TabIndex = 5;
            m_sizeLabel.Text = "Размерность:";
            // 
            // m_nameLabel
            // 
            m_nameLabel.AutoSize = true;
            m_nameLabel.Location = new System.Drawing.Point(908, 48);
            m_nameLabel.Name = "m_nameLabel";
            m_nameLabel.Size = new System.Drawing.Size(76, 16);
            m_nameLabel.TabIndex = 3;
            m_nameLabel.Text = "Название:";
            // 
            // bookIncome_B_idLabel
            // 
            bookIncome_B_idLabel.AutoSize = true;
            bookIncome_B_idLabel.Location = new System.Drawing.Point(908, 18);
            bookIncome_B_idLabel.Name = "bookIncome_B_idLabel";
            bookIncome_B_idLabel.Size = new System.Drawing.Size(88, 16);
            bookIncome_B_idLabel.TabIndex = 1;
            bookIncome_B_idLabel.Text = "id предмета:";
            // 
            // b_wayLabel
            // 
            b_wayLabel.AutoSize = true;
            b_wayLabel.Location = new System.Drawing.Point(809, 47);
            b_wayLabel.Name = "b_wayLabel";
            b_wayLabel.Size = new System.Drawing.Size(132, 16);
            b_wayLabel.TabIndex = 6;
            b_wayLabel.Text = "Способ получения:";
            // 
            // b_timeLabel
            // 
            b_timeLabel.AutoSize = true;
            b_timeLabel.Location = new System.Drawing.Point(809, 18);
            b_timeLabel.Name = "b_timeLabel";
            b_timeLabel.Size = new System.Drawing.Size(130, 16);
            b_timeLabel.TabIndex = 4;
            b_timeLabel.Text = "Дата поступления:";
            // 
            // dataSet1
            // 
            this.dataSet1.DataSetName = "DataSet1";
            this.dataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // bookIncomeBindingSource
            // 
            this.bookIncomeBindingSource.DataMember = "BookIncome";
            this.bookIncomeBindingSource.DataSource = this.dataSet1;
            // 
            // bookIncomeTableAdapter
            // 
            this.bookIncomeTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.BookIncomeTableAdapter = this.bookIncomeTableAdapter;
            this.tableAdapterManager.DescriptionTableAdapter = this.descriptionTableAdapter;
            this.tableAdapterManager.InventoryTableAdapter = this.inventoryTableAdapter;
            this.tableAdapterManager.MuseumObjectTableAdapter = this.museumObjectTableAdapter;
            this.tableAdapterManager.UpdateOrder = WindowsFormsApp4.DataSet1TableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // descriptionTableAdapter
            // 
            this.descriptionTableAdapter.ClearBeforeFill = true;
            // 
            // inventoryTableAdapter
            // 
            this.inventoryTableAdapter.ClearBeforeFill = true;
            // 
            // museumObjectTableAdapter
            // 
            this.museumObjectTableAdapter.ClearBeforeFill = true;
            // 
            // museumObjectBindingSource
            // 
            this.museumObjectBindingSource.DataMember = "MuseumObject";
            this.museumObjectBindingSource.DataSource = this.dataSet1;
            // 
            // inventoryBindingSource
            // 
            this.inventoryBindingSource.DataMember = "Inventory";
            this.inventoryBindingSource.DataSource = this.dataSet1;
            // 
            // descriptionBindingSource
            // 
            this.descriptionBindingSource.DataMember = "Description";
            this.descriptionBindingSource.DataSource = this.dataSet1;
            // 
            // tabPage4
            // 
            this.tabPage4.AutoScroll = true;
            this.tabPage4.Controls.Add(this.button12);
            this.tabPage4.Controls.Add(this.button7);
            this.tabPage4.Controls.Add(this.button8);
            this.tabPage4.Controls.Add(museumObject_BookIncome_B_idLabel1);
            this.tabPage4.Controls.Add(this.museumObject_BookIncome_B_idComboBox1);
            this.tabPage4.Controls.Add(d_avtorLabel);
            this.tabPage4.Controls.Add(this.d_avtorTextBox);
            this.tabPage4.Controls.Add(this.d_descriptionTextBox);
            this.tabPage4.Controls.Add(d_descriptionLabel);
            this.tabPage4.Controls.Add(this.descriptionDataGridView);
            this.tabPage4.Location = new System.Drawing.Point(4, 25);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(1163, 596);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Научное описание";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // button12
            // 
            this.button12.Location = new System.Drawing.Point(896, 428);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(250, 68);
            this.button12.TabIndex = 17;
            this.button12.Text = "Удалить";
            this.button12.UseVisualStyleBackColor = true;
            this.button12.Click += new System.EventHandler(this.button12_Click);
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(896, 281);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(250, 68);
            this.button7.TabIndex = 16;
            this.button7.Text = "Сохранить";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(896, 162);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(250, 68);
            this.button8.TabIndex = 15;
            this.button8.Text = "Новая запись";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // museumObject_BookIncome_B_idComboBox1
            // 
            this.museumObject_BookIncome_B_idComboBox1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.descriptionBindingSource, "MuseumObject_BookIncome_B_id", true));
            this.museumObject_BookIncome_B_idComboBox1.DataSource = this.museumObjectBindingSource;
            this.museumObject_BookIncome_B_idComboBox1.DisplayMember = "BookIncome_B_id";
            this.museumObject_BookIncome_B_idComboBox1.FormattingEnabled = true;
            this.museumObject_BookIncome_B_idComboBox1.Location = new System.Drawing.Point(1015, 19);
            this.museumObject_BookIncome_B_idComboBox1.Name = "museumObject_BookIncome_B_idComboBox1";
            this.museumObject_BookIncome_B_idComboBox1.Size = new System.Drawing.Size(121, 24);
            this.museumObject_BookIncome_B_idComboBox1.TabIndex = 2;
            this.museumObject_BookIncome_B_idComboBox1.ValueMember = "BookIncome_B_id";
            // 
            // d_avtorTextBox
            // 
            this.d_avtorTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.descriptionBindingSource, "D_avtor", true));
            this.d_avtorTextBox.Location = new System.Drawing.Point(1015, 49);
            this.d_avtorTextBox.Name = "d_avtorTextBox";
            this.d_avtorTextBox.Size = new System.Drawing.Size(121, 22);
            this.d_avtorTextBox.TabIndex = 4;
            this.d_avtorTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.d_avtorTextBox_KeyPress);
            // 
            // d_descriptionTextBox
            // 
            this.d_descriptionTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.descriptionBindingSource, "D_description", true));
            this.d_descriptionTextBox.Location = new System.Drawing.Point(1015, 77);
            this.d_descriptionTextBox.Name = "d_descriptionTextBox";
            this.d_descriptionTextBox.Size = new System.Drawing.Size(121, 22);
            this.d_descriptionTextBox.TabIndex = 6;
            this.d_descriptionTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.d_descriptionTextBox_KeyPress);
            // 
            // descriptionDataGridView
            // 
            this.descriptionDataGridView.AutoGenerateColumns = false;
            this.descriptionDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.descriptionDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn13,
            this.dataGridViewTextBoxColumn14,
            this.dataGridViewTextBoxColumn15});
            this.descriptionDataGridView.DataSource = this.descriptionBindingSource;
            this.descriptionDataGridView.Location = new System.Drawing.Point(0, 0);
            this.descriptionDataGridView.Name = "descriptionDataGridView";
            this.descriptionDataGridView.RowHeadersWidth = 51;
            this.descriptionDataGridView.RowTemplate.Height = 24;
            this.descriptionDataGridView.Size = new System.Drawing.Size(873, 584);
            this.descriptionDataGridView.TabIndex = 0;
            // 
            // dataGridViewTextBoxColumn13
            // 
            this.dataGridViewTextBoxColumn13.DataPropertyName = "MuseumObject_BookIncome_B_id";
            this.dataGridViewTextBoxColumn13.HeaderText = "id";
            this.dataGridViewTextBoxColumn13.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn13.Name = "dataGridViewTextBoxColumn13";
            this.dataGridViewTextBoxColumn13.Width = 125;
            // 
            // dataGridViewTextBoxColumn14
            // 
            this.dataGridViewTextBoxColumn14.DataPropertyName = "D_avtor";
            this.dataGridViewTextBoxColumn14.HeaderText = "Автор";
            this.dataGridViewTextBoxColumn14.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn14.Name = "dataGridViewTextBoxColumn14";
            this.dataGridViewTextBoxColumn14.Width = 125;
            // 
            // dataGridViewTextBoxColumn15
            // 
            this.dataGridViewTextBoxColumn15.DataPropertyName = "D_description";
            this.dataGridViewTextBoxColumn15.HeaderText = "Научное описание";
            this.dataGridViewTextBoxColumn15.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn15.Name = "dataGridViewTextBoxColumn15";
            this.dataGridViewTextBoxColumn15.Width = 125;
            // 
            // tabPage3
            // 
            this.tabPage3.AutoScroll = true;
            this.tabPage3.Controls.Add(this.button11);
            this.tabPage3.Controls.Add(fund_idFundLabel);
            this.tabPage3.Controls.Add(this.fund_idFundComboBox);
            this.tabPage3.Controls.Add(this.button5);
            this.tabPage3.Controls.Add(this.button6);
            this.tabPage3.Controls.Add(location_idLocationLabel);
            this.tabPage3.Controls.Add(this.location_idLocationTextBox);
            this.tabPage3.Controls.Add(museumObject_BookIncome_B_idLabel);
            this.tabPage3.Controls.Add(this.museumObject_BookIncome_B_idComboBox);
            this.tabPage3.Controls.Add(i_dateLabel);
            this.tabPage3.Controls.Add(this.i_dateDateTimePicker);
            this.tabPage3.Controls.Add(this.inventoryDataGridView);
            this.tabPage3.Location = new System.Drawing.Point(4, 25);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(1163, 596);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Инветарь";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // button11
            // 
            this.button11.Location = new System.Drawing.Point(859, 467);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(250, 68);
            this.button11.TabIndex = 16;
            this.button11.Text = "Удалить";
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // fund_idFundComboBox
            // 
            this.fund_idFundComboBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.inventoryBindingSource, "Fund_idFund", true));
            this.fund_idFundComboBox.FormattingEnabled = true;
            this.fund_idFundComboBox.Items.AddRange(new object[] {
            "Художественный",
            "Скульптурный",
            "Живопись",
            "Графика",
            "Археологический",
            "Книги",
            "Оружие",
            "Документы",
            "Естественный",
            "Прочее"});
            this.fund_idFundComboBox.Location = new System.Drawing.Point(935, 45);
            this.fund_idFundComboBox.Name = "fund_idFundComboBox";
            this.fund_idFundComboBox.Size = new System.Drawing.Size(200, 24);
            this.fund_idFundComboBox.TabIndex = 15;
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(859, 329);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(250, 68);
            this.button5.TabIndex = 14;
            this.button5.Text = "Сохранить";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(859, 210);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(250, 68);
            this.button6.TabIndex = 13;
            this.button6.Text = "Новая запись";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // location_idLocationTextBox
            // 
            this.location_idLocationTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.inventoryBindingSource, "Location_idLocation", true));
            this.location_idLocationTextBox.Location = new System.Drawing.Point(935, 75);
            this.location_idLocationTextBox.Name = "location_idLocationTextBox";
            this.location_idLocationTextBox.Size = new System.Drawing.Size(200, 22);
            this.location_idLocationTextBox.TabIndex = 4;
            this.location_idLocationTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.location_idLocationTextBox_KeyPress);
            // 
            // museumObject_BookIncome_B_idComboBox
            // 
            this.museumObject_BookIncome_B_idComboBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.inventoryBindingSource, "MuseumObject_BookIncome_B_id", true));
            this.museumObject_BookIncome_B_idComboBox.DataSource = this.museumObjectBindingSource;
            this.museumObject_BookIncome_B_idComboBox.DisplayMember = "BookIncome_B_id";
            this.museumObject_BookIncome_B_idComboBox.FormattingEnabled = true;
            this.museumObject_BookIncome_B_idComboBox.Location = new System.Drawing.Point(935, 17);
            this.museumObject_BookIncome_B_idComboBox.Name = "museumObject_BookIncome_B_idComboBox";
            this.museumObject_BookIncome_B_idComboBox.Size = new System.Drawing.Size(200, 24);
            this.museumObject_BookIncome_B_idComboBox.TabIndex = 6;
            this.museumObject_BookIncome_B_idComboBox.ValueMember = "BookIncome_B_id";
            // 
            // i_dateDateTimePicker
            // 
            this.i_dateDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.inventoryBindingSource, "I_date", true));
            this.i_dateDateTimePicker.Location = new System.Drawing.Point(935, 101);
            this.i_dateDateTimePicker.Name = "i_dateDateTimePicker";
            this.i_dateDateTimePicker.Size = new System.Drawing.Size(200, 22);
            this.i_dateDateTimePicker.TabIndex = 8;
            // 
            // inventoryDataGridView
            // 
            this.inventoryDataGridView.AutoGenerateColumns = false;
            this.inventoryDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.inventoryDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn11,
            this.dataGridViewTextBoxColumn9,
            this.dataGridViewTextBoxColumn10,
            this.dataGridViewTextBoxColumn12});
            this.inventoryDataGridView.DataSource = this.inventoryBindingSource;
            this.inventoryDataGridView.Location = new System.Drawing.Point(0, 0);
            this.inventoryDataGridView.Name = "inventoryDataGridView";
            this.inventoryDataGridView.RowHeadersWidth = 51;
            this.inventoryDataGridView.RowTemplate.Height = 24;
            this.inventoryDataGridView.Size = new System.Drawing.Size(787, 572);
            this.inventoryDataGridView.TabIndex = 0;
            // 
            // dataGridViewTextBoxColumn11
            // 
            this.dataGridViewTextBoxColumn11.DataPropertyName = "MuseumObject_BookIncome_B_id";
            this.dataGridViewTextBoxColumn11.HeaderText = "id";
            this.dataGridViewTextBoxColumn11.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn11.Name = "dataGridViewTextBoxColumn11";
            this.dataGridViewTextBoxColumn11.Width = 125;
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.DataPropertyName = "Fund_idFund";
            this.dataGridViewTextBoxColumn9.HeaderText = "Фонд";
            this.dataGridViewTextBoxColumn9.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            this.dataGridViewTextBoxColumn9.Width = 125;
            // 
            // dataGridViewTextBoxColumn10
            // 
            this.dataGridViewTextBoxColumn10.DataPropertyName = "Location_idLocation";
            this.dataGridViewTextBoxColumn10.HeaderText = "Местохранения";
            this.dataGridViewTextBoxColumn10.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            this.dataGridViewTextBoxColumn10.Width = 125;
            // 
            // dataGridViewTextBoxColumn12
            // 
            this.dataGridViewTextBoxColumn12.DataPropertyName = "I_date";
            this.dataGridViewTextBoxColumn12.HeaderText = "Дата поступления в фонд";
            this.dataGridViewTextBoxColumn12.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn12.Name = "dataGridViewTextBoxColumn12";
            this.dataGridViewTextBoxColumn12.Width = 125;
            // 
            // tabPage2
            // 
            this.tabPage2.AutoScroll = true;
            this.tabPage2.Controls.Add(this.button10);
            this.tabPage2.Controls.Add(this.button3);
            this.tabPage2.Controls.Add(this.button4);
            this.tabPage2.Controls.Add(bookIncome_B_idLabel);
            this.tabPage2.Controls.Add(this.bookIncome_B_idComboBox);
            this.tabPage2.Controls.Add(m_nameLabel);
            this.tabPage2.Controls.Add(this.m_nameTextBox);
            this.tabPage2.Controls.Add(this.m_sizeTextBox);
            this.tabPage2.Controls.Add(this.m_materialTextBox);
            this.tabPage2.Controls.Add(this.m_safetyTextBox);
            this.tabPage2.Controls.Add(m_sizeLabel);
            this.tabPage2.Controls.Add(m_materialLabel);
            this.tabPage2.Controls.Add(m_safetyLabel);
            this.tabPage2.Controls.Add(this.museumObjectDataGridView);
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1163, 596);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Музейные предметы";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(891, 470);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(250, 68);
            this.button10.TabIndex = 13;
            this.button10.Text = "Удалить";
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(891, 326);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(250, 68);
            this.button3.TabIndex = 12;
            this.button3.Text = "Сохранить";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(891, 207);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(250, 68);
            this.button4.TabIndex = 11;
            this.button4.Text = "Новая запись";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // bookIncome_B_idComboBox
            // 
            this.bookIncome_B_idComboBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.museumObjectBindingSource, "BookIncome_B_id", true));
            this.bookIncome_B_idComboBox.DataSource = this.bookIncomeBindingSource;
            this.bookIncome_B_idComboBox.DisplayMember = "B_id";
            this.bookIncome_B_idComboBox.FormattingEnabled = true;
            this.bookIncome_B_idComboBox.Location = new System.Drawing.Point(1010, 15);
            this.bookIncome_B_idComboBox.Name = "bookIncome_B_idComboBox";
            this.bookIncome_B_idComboBox.Size = new System.Drawing.Size(121, 24);
            this.bookIncome_B_idComboBox.TabIndex = 2;
            this.bookIncome_B_idComboBox.ValueMember = "B_id";
            // 
            // m_nameTextBox
            // 
            this.m_nameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.museumObjectBindingSource, "M_name", true));
            this.m_nameTextBox.Location = new System.Drawing.Point(1010, 45);
            this.m_nameTextBox.Name = "m_nameTextBox";
            this.m_nameTextBox.Size = new System.Drawing.Size(121, 22);
            this.m_nameTextBox.TabIndex = 4;
            this.m_nameTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.m_nameTextBox_KeyPress);
            // 
            // m_sizeTextBox
            // 
            this.m_sizeTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.museumObjectBindingSource, "M_size", true));
            this.m_sizeTextBox.Location = new System.Drawing.Point(1010, 73);
            this.m_sizeTextBox.Name = "m_sizeTextBox";
            this.m_sizeTextBox.Size = new System.Drawing.Size(121, 22);
            this.m_sizeTextBox.TabIndex = 6;
            // 
            // m_materialTextBox
            // 
            this.m_materialTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.museumObjectBindingSource, "M_material", true));
            this.m_materialTextBox.Location = new System.Drawing.Point(1010, 101);
            this.m_materialTextBox.Name = "m_materialTextBox";
            this.m_materialTextBox.Size = new System.Drawing.Size(121, 22);
            this.m_materialTextBox.TabIndex = 8;
            this.m_materialTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.m_materialTextBox_KeyPress);
            // 
            // m_safetyTextBox
            // 
            this.m_safetyTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.museumObjectBindingSource, "M_safety", true));
            this.m_safetyTextBox.Location = new System.Drawing.Point(1010, 129);
            this.m_safetyTextBox.Name = "m_safetyTextBox";
            this.m_safetyTextBox.Size = new System.Drawing.Size(121, 22);
            this.m_safetyTextBox.TabIndex = 10;
            this.m_safetyTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.m_safetyTextBox_KeyPress);
            // 
            // museumObjectDataGridView
            // 
            this.museumObjectDataGridView.AutoGenerateColumns = false;
            this.museumObjectDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.museumObjectDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn8});
            this.museumObjectDataGridView.DataSource = this.museumObjectBindingSource;
            this.museumObjectDataGridView.Location = new System.Drawing.Point(0, 0);
            this.museumObjectDataGridView.Name = "museumObjectDataGridView";
            this.museumObjectDataGridView.RowHeadersWidth = 51;
            this.museumObjectDataGridView.RowTemplate.Height = 24;
            this.museumObjectDataGridView.Size = new System.Drawing.Size(882, 587);
            this.museumObjectDataGridView.TabIndex = 0;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "BookIncome_B_id";
            this.dataGridViewTextBoxColumn4.HeaderText = "id";
            this.dataGridViewTextBoxColumn4.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.Width = 125;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "M_name";
            this.dataGridViewTextBoxColumn5.HeaderText = "Название";
            this.dataGridViewTextBoxColumn5.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.Width = 125;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "M_size";
            this.dataGridViewTextBoxColumn6.HeaderText = "Размер";
            this.dataGridViewTextBoxColumn6.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.Width = 125;
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "M_material";
            this.dataGridViewTextBoxColumn7.HeaderText = "Материал";
            this.dataGridViewTextBoxColumn7.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.Width = 125;
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.DataPropertyName = "M_safety";
            this.dataGridViewTextBoxColumn8.HeaderText = "Сохранность";
            this.dataGridViewTextBoxColumn8.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            this.dataGridViewTextBoxColumn8.Width = 125;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.button9);
            this.tabPage1.Controls.Add(this.bookIncomeDataGridView);
            this.tabPage1.Controls.Add(this.button2);
            this.tabPage1.Controls.Add(this.button1);
            this.tabPage1.Controls.Add(this.b_wayTextBox);
            this.tabPage1.Controls.Add(b_timeLabel);
            this.tabPage1.Controls.Add(b_wayLabel);
            this.tabPage1.Controls.Add(this.b_timeDateTimePicker);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1163, 596);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Книга поступлений";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(895, 401);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(250, 68);
            this.button9.TabIndex = 10;
            this.button9.Text = "Удалить";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // bookIncomeDataGridView
            // 
            this.bookIncomeDataGridView.AutoGenerateColumns = false;
            this.bookIncomeDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.bookIncomeDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3});
            this.bookIncomeDataGridView.DataSource = this.bookIncomeBindingSource;
            this.bookIncomeDataGridView.Location = new System.Drawing.Point(0, 0);
            this.bookIncomeDataGridView.Name = "bookIncomeDataGridView";
            this.bookIncomeDataGridView.RowHeadersWidth = 51;
            this.bookIncomeDataGridView.RowTemplate.Height = 24;
            this.bookIncomeDataGridView.Size = new System.Drawing.Size(808, 587);
            this.bookIncomeDataGridView.TabIndex = 1;
 
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "B_id";
            this.dataGridViewTextBoxColumn1.HeaderText = "Id";
            this.dataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.Width = 125;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "B_time";
            this.dataGridViewTextBoxColumn2.HeaderText = "Дата поступления";
            this.dataGridViewTextBoxColumn2.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.Width = 125;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "B_way";
            this.dataGridViewTextBoxColumn3.HeaderText = "Способ получения";
            this.dataGridViewTextBoxColumn3.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.Width = 125;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(895, 218);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(250, 68);
            this.button2.TabIndex = 9;
            this.button2.Text = "Сохранить";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(895, 99);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(250, 68);
            this.button1.TabIndex = 8;
            this.button1.Text = "Новая запись";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // b_wayTextBox
            // 
            this.b_wayTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bookIncomeBindingSource, "B_way", true));
            this.b_wayTextBox.Location = new System.Drawing.Point(945, 41);
            this.b_wayTextBox.Name = "b_wayTextBox";
            this.b_wayTextBox.Size = new System.Drawing.Size(200, 22);
            this.b_wayTextBox.TabIndex = 7;
            this.b_wayTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.b_wayTextBox_KeyPress);
            // 
            // b_timeDateTimePicker
            // 
            this.b_timeDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.bookIncomeBindingSource, "B_time", true));
            this.b_timeDateTimePicker.Location = new System.Drawing.Point(945, 13);
            this.b_timeDateTimePicker.Name = "b_timeDateTimePicker";
            this.b_timeDateTimePicker.Size = new System.Drawing.Size(200, 22);
            this.b_timeDateTimePicker.TabIndex = 5;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Location = new System.Drawing.Point(5, 1);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1171, 625);
            this.tabControl1.TabIndex = 10;
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.button13);
            this.tabPage5.Location = new System.Drawing.Point(4, 25);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(1163, 596);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "Акт сверки";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // button13
            // 
            this.button13.Location = new System.Drawing.Point(319, 179);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(463, 186);
            this.button13.TabIndex = 0;
            this.button13.Text = "Создать акт сверки в EXCEL";
            this.button13.UseVisualStyleBackColor = true;
            this.button13.Click += new System.EventHandler(this.button13_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1188, 629);
            this.Controls.Add(this.tabControl1);
            this.Name = "Form1";
            this.Text = "Учёт музейных предметов";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bookIncomeBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.museumObjectBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.inventoryBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.descriptionBindingSource)).EndInit();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.descriptionDataGridView)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.inventoryDataGridView)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.museumObjectDataGridView)).EndInit();
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bookIncomeDataGridView)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.tabPage5.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private DataSet1 dataSet1;
        private System.Windows.Forms.BindingSource bookIncomeBindingSource;
        private DataSet1TableAdapters.BookIncomeTableAdapter bookIncomeTableAdapter;
        private DataSet1TableAdapters.TableAdapterManager tableAdapterManager;
        private DataSet1TableAdapters.MuseumObjectTableAdapter museumObjectTableAdapter;
        private System.Windows.Forms.BindingSource museumObjectBindingSource;
        private DataSet1TableAdapters.InventoryTableAdapter inventoryTableAdapter;
        private System.Windows.Forms.BindingSource inventoryBindingSource;
        private DataSet1TableAdapters.DescriptionTableAdapter descriptionTableAdapter;
        private System.Windows.Forms.BindingSource descriptionBindingSource;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.ComboBox museumObject_BookIncome_B_idComboBox1;
        private System.Windows.Forms.TextBox d_avtorTextBox;
        private System.Windows.Forms.TextBox d_descriptionTextBox;
        private System.Windows.Forms.DataGridView descriptionDataGridView;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.ComboBox fund_idFundComboBox;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.TextBox location_idLocationTextBox;
        private System.Windows.Forms.ComboBox museumObject_BookIncome_B_idComboBox;
        private System.Windows.Forms.DateTimePicker i_dateDateTimePicker;
        private System.Windows.Forms.DataGridView inventoryDataGridView;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.ComboBox bookIncome_B_idComboBox;
        private System.Windows.Forms.TextBox m_nameTextBox;
        private System.Windows.Forms.TextBox m_sizeTextBox;
        private System.Windows.Forms.TextBox m_materialTextBox;
        private System.Windows.Forms.TextBox m_safetyTextBox;
        private System.Windows.Forms.DataGridView museumObjectDataGridView;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.DataGridView bookIncomeDataGridView;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox b_wayTextBox;
        private System.Windows.Forms.DateTimePicker b_timeDateTimePicker;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn13;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn14;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn15;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn12;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.Button button13;
    }
}

