﻿using System;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using OfficeOpenXml;
using System.Data.SqlClient;
using System.Data;
using System.IO;
using System.Collections.Generic;
using System.Linq;

namespace WindowsFormsApp4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void bookIncomeBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.bookIncomeBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.dataSet1);

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "dataSet1.Description". При необходимости она может быть перемещена или удалена.
            this.descriptionTableAdapter.Fill(this.dataSet1.Description);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "dataSet1.Inventory". При необходимости она может быть перемещена или удалена.
            this.inventoryTableAdapter.Fill(this.dataSet1.Inventory);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "dataSet1.MuseumObject". При необходимости она может быть перемещена или удалена.
            this.museumObjectTableAdapter.Fill(this.dataSet1.MuseumObject);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "dataSet1.MuseumObject". При необходимости она может быть перемещена или удалена.
            this.museumObjectTableAdapter.Fill(this.dataSet1.MuseumObject);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "dataSet1.MuseumObject". При необходимости она может быть перемещена или удалена.
            this.museumObjectTableAdapter.Fill(this.dataSet1.MuseumObject);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "dataSet1.BookIncome". При необходимости она может быть перемещена или удалена.
            this.bookIncomeTableAdapter.Fill(this.dataSet1.BookIncome);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            bookIncomeBindingSource.AddNew();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            bookIncomeBindingSource.EndEdit();
            bookIncomeTableAdapter.Update(dataSet1);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            museumObjectBindingSource.AddNew();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            museumObjectBindingSource.EndEdit();
            museumObjectTableAdapter.Update(dataSet1);
        }

        private void button6_Click(object sender, EventArgs e)
        {
            inventoryBindingSource.AddNew();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            inventoryBindingSource.EndEdit();
            inventoryTableAdapter.Update(dataSet1);
        }

        private void button8_Click(object sender, EventArgs e)
        {
            descriptionBindingSource.AddNew();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            descriptionBindingSource.EndEdit();
            descriptionTableAdapter.Update(dataSet1);
        }

        private void b_wayTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            string Symbol = e.KeyChar.ToString();

            if (!Regex.Match(Symbol, @"[а-яА-Я]|[a-zA-Z]|[ ]").Success)
            {
                e.Handled = true;
            }
        }

        private void m_nameTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            string Symbol = e.KeyChar.ToString();

            if (!Regex.Match(Symbol, @"[а-яА-Я]|[a-zA-Z]|[ ]").Success)
            {
                e.Handled = true;
            }
        }

        private void m_materialTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            string Symbol = e.KeyChar.ToString();

            if (!Regex.Match(Symbol, @"[а-яА-Я]|[a-zA-Z]|[ ]").Success)
            {
                e.Handled = true;
            }
        }

        private void m_safetyTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            string Symbol = e.KeyChar.ToString();

            if (!Regex.Match(Symbol, @"[а-яА-Я]|[a-zA-Z]|[ ]").Success)
            {
                e.Handled = true;
            }
        }

        private void location_idLocationTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            string Symbol = e.KeyChar.ToString();

            if (!Regex.Match(Symbol, @"[а-яА-Я]|[a-zA-Z]|[ ]").Success)
            {
                e.Handled = true;
            }
        }

        private void d_avtorTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            string Symbol = e.KeyChar.ToString();

            if (!Regex.Match(Symbol, @"[а-яА-Я]|[a-zA-Z]|[ ]").Success)
            {
                e.Handled = true;
            }
        }

        private void d_descriptionTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            string Symbol = e.KeyChar.ToString();

            if (!Regex.Match(Symbol, @"[а-яА-Я]|[a-zA-Z]|[ ]").Success)
            {
                e.Handled = true;
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Вы действительно хотите удалить запись?", "Внимание", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                foreach (DataGridViewRow item in this.bookIncomeDataGridView.SelectedRows)
                {
                    bookIncomeDataGridView.Rows.RemoveAt(item.Index);
                }
            }
        }

        private void button12_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Вы действительно хотите удалить запись?", "Внимание", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                foreach (DataGridViewRow item in this.descriptionDataGridView.SelectedRows)
                {
                    descriptionDataGridView.Rows.RemoveAt(item.Index);
                }
            }
        }

        private void button11_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Вы действительно хотите удалить запись?", "Внимание", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                foreach (DataGridViewRow item in this.inventoryDataGridView.SelectedRows)
                {
                    inventoryDataGridView.Rows.RemoveAt(item.Index);
                }
            }
        }

        private void button10_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Вы действительно хотите удалить запись?", "Внимание", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                foreach (DataGridViewRow item in this.museumObjectDataGridView.SelectedRows)
                {
                    museumObjectDataGridView.Rows.RemoveAt(item.Index);
                }
            }
        }

        private DataTable GetBookIncomeData()
        {
            string connectionString = ".\\SQLEXPRESS"; // Замените на свое подключение к базе данных
            string query = "SELECT B_time, B_way FROM BookIncome";

            DataTable dataTable = new DataTable();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                SqlDataAdapter dataAdapter = new SqlDataAdapter(command);
                dataAdapter.Fill(dataTable);
            }

            return dataTable;
        }


        private void button13_Click(object sender, EventArgs e)
        {
            try
            {
                ExcelPackage.LicenseContext = LicenseContext.NonCommercial; // Установка контекста лицензирования
                using (ExcelPackage package = new ExcelPackage())
                {
                    ExcelWorkbook workbook = package.Workbook;
                    ExcelWorksheet worksheet = workbook.Worksheets.Add("DataSheet");

                    // Получение выбранных данных из первого DataGridView
                    List<DataGridViewRow> selectedRows1 = museumObjectDataGridView.SelectedRows.Count > 0 ?
                        new List<DataGridViewRow>(museumObjectDataGridView.SelectedRows.Cast<DataGridViewRow>()) :
                        new List<DataGridViewRow>(museumObjectDataGridView.Rows.Cast<DataGridViewRow>());

                    // Сохранение выбранных данных из первого DataGridView в Excel
                    SaveSelectedDataToWorksheet(selectedRows1, museumObjectDataGridView, worksheet, 1, new int[] { 1, 4 });

                    // Получение выбранных данных из второго DataGridView
                    List<DataGridViewRow> selectedRows2 = inventoryDataGridView.SelectedRows.Count > 0 ?
                        new List<DataGridViewRow>(inventoryDataGridView.SelectedRows.Cast<DataGridViewRow>()) :
                        new List<DataGridViewRow>(inventoryDataGridView.Rows.Cast<DataGridViewRow>());

                    // Сохранение выбранных данных из второго DataGridView в Excel
                    SaveSelectedDataToWorksheet(selectedRows2, inventoryDataGridView, worksheet, selectedRows1.Count + 3, new int[] { 1, 2, 3 });

                    // Получение выбранных данных из третьего DataGridView
                    List<DataGridViewRow> selectedRows3 = bookIncomeDataGridView.SelectedRows.Count > 0 ?
                        new List<DataGridViewRow>(bookIncomeDataGridView.SelectedRows.Cast<DataGridViewRow>()) :
                        new List<DataGridViewRow>(bookIncomeDataGridView.Rows.Cast<DataGridViewRow>());

                    // Сохранение выбранных данных из третьего DataGridView в Excel
                    SaveSelectedDataToWorksheet(selectedRows3, bookIncomeDataGridView, worksheet, selectedRows1.Count + selectedRows2.Count + 5, new int[] { 1, 2 });

                    // Сохранение файла Excel
                    string desktopPath = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
                    string fileName = Path.Combine(desktopPath, "ExcelData_" + DateTime.Now.ToString("yyyyMMdd_HHmmss") + ".xlsx");
                    if (!string.IsNullOrEmpty(fileName))
                    {
                        package.SaveAs(new FileInfo(fileName));
                        MessageBox.Show("Выбранные данные успешно сохранены в файл Excel.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Произошла ошибка при сохранении в файл Excel: " + ex.Message);
            }
        }

        private void SaveSelectedDataToWorksheet(List<DataGridViewRow> selectedRows, DataGridView dataGridView, ExcelWorksheet worksheet, int startRow, int[] columnIndexes)
        {
            // Сохранение заголовков столбцов
            for (int col = 0; col < columnIndexes.Length; col++)
            {
                int columnIndex = columnIndexes[col];
                worksheet.Cells[startRow, col + 1].Value = dataGridView.Columns[columnIndex].HeaderText;
            }

            // Сохранение выбранных данных ячеек
            for (int i = 0; i < selectedRows.Count; i++)
            {
                DataGridViewRow row = selectedRows[i];
                for (int col = 0; col < columnIndexes.Length; col++)
                {
                    int columnIndex = columnIndexes[col];
                    worksheet.Cells[startRow + i + 1, col + 1].Value = row.Cells[columnIndex].Value;
                }
            }
        }
    }
}
